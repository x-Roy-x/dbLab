package com.kopach.exceptions;

public class ExistsShopperForPasswordOfShopperException extends Exception {
}
