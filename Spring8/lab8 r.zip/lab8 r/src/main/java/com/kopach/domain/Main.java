package com.kopach.domain;

public class Main {
    public  static void main(String args[]){

    }
}
