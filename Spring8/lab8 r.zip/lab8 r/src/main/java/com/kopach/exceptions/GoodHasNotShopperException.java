package com.kopach.exceptions;

public class GoodHasNotShopperException extends Exception {
}
