package com.kopach.DTO.impl;

import com.kopach.DTO.DTO;
import com.kopach.domain.PasswordOfShopper;
import com.kopach.domain.Shopper;
import com.kopach.exceptions.NoSuchShopperException;
import com.kopach.exceptions.NoSuchPasswordOfShopperException;
import com.kopach.exceptions.NoSuchGoodException;
import org.springframework.hateoas.Link;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

public class ShopperDTO extends DTO<Shopper> {
    public ShopperDTO(Shopper mobile, Link link) throws NoSuchGoodException, NoSuchPasswordOfShopperException, NoSuchShopperException {
        super(mobile, link);
    }

    public Long getShopperId() {
        return getEntity().getId();
    }

    public String getName_of_shopper() {
        return getEntity().getName_of_shopper();
    }

    public String getSurname_of_shopper() {
        return getEntity().getSurname_of_shopper();
    }

    public PasswordOfShopper getPassword_by_shopper() {
        return getEntity().getPasswordByPassword();
    }


}
