package com.kopach.exceptions;

public class ExistsGoodForShopperException extends Exception {
}
