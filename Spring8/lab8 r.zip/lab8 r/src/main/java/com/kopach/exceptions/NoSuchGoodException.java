package com.kopach.exceptions;

public class NoSuchGoodException extends Exception {
}
