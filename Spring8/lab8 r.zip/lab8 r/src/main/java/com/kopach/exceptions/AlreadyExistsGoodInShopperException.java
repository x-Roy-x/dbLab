package com.kopach.exceptions;

public class AlreadyExistsGoodInShopperException extends Throwable {
}
