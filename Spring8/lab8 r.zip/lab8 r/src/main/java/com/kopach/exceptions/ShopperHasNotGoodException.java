package com.kopach.exceptions;

public class ShopperHasNotGoodException extends Exception {
}
