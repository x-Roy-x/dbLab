package com.kopach.exceptions;

public class NoSuchPasswordOfShopperException extends Exception {
}
