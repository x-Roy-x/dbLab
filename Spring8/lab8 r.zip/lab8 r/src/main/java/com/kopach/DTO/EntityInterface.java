package com.kopach.DTO;

public interface EntityInterface {
    Long getId();
}
