package com.kopach.exceptions;

public class AlreadyExistsShopperInGoodException extends Exception {
}
