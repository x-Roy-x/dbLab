package com.kopach.DTO.impl;

import com.kopach.DTO.DTO;
import com.kopach.controller.ShopperController;
import com.kopach.domain.PasswordOfShopper;
import com.kopach.domain.Shopper;
import com.kopach.exceptions.NoSuchShopperException;
import com.kopach.exceptions.NoSuchPasswordOfShopperException;
import com.kopach.exceptions.NoSuchGoodException;
import org.springframework.hateoas.Link;

import java.util.Set;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;


public class PasswordOfShopperDTO extends DTO<PasswordOfShopper> {
    public PasswordOfShopperDTO(PasswordOfShopper cpu, Link link) throws NoSuchPasswordOfShopperException, NoSuchGoodException, NoSuchShopperException {
        super(cpu, link);
        add(linkTo(methodOn(ShopperController.class).getShoppersByPasswordId(getEntity().getId())).withRel("mobile"));
    }

    public Long getShopperId() {
        return getEntity().getId();
    }

    public Integer getPasswordOfShopper() {
        return getEntity().getPasswordOfShopper();
    }
  

    public Set<Shopper> getShoppers() {
        return getEntity().getShopper();
    }
}
