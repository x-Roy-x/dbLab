package com.kopach.exceptions;

public class ExistsShopperForProjectException extends Exception {
}
