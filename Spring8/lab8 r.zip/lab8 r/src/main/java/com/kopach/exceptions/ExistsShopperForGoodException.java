package com.kopach.exceptions;

public class ExistsShopperForGoodException extends Exception {
}
