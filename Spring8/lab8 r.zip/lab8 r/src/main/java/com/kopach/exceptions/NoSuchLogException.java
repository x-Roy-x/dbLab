package com.kopach.exceptions;

public class NoSuchLogException extends Exception {
}
