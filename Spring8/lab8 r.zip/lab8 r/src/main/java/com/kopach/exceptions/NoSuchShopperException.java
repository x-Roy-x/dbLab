package com.kopach.exceptions;

public class NoSuchShopperException extends Exception {
}
