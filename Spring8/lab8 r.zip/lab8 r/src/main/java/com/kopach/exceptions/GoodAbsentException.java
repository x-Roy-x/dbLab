package com.kopach.exceptions;

public class GoodAbsentException extends Exception {
}
