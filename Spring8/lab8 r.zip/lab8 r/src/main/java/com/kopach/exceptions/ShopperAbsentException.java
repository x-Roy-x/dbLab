package com.kopach.exceptions;

public class ShopperAbsentException extends Exception {
}
